<?  //header('Content-type: text/html; charset=windows-1251');
	//include ("../blocks/db.php");
	session_start();
header('Content-type: text/html; charset=utf-8');

	if(empty($_SESSION['login_user']))
	{
		header('Location: index.php');
	}

	$db = mysql_connect ("localhost","inventoryuser","12345");
	
	mysql_select_db("inventory",$db);
	
	include("../blocks/functions.php");
    mysqli_set_charset ($db, 'utf8');
	
	$page = "locations";
	if (isset($_GET['id'])) {$location_id = $_GET['id'];}
	if (!isset($location_id)||!location_exists($location_id)) {$location_id = 1;}
	
	if (isset($_SESSION['location_id'])){$location_id = $_SESSION['location_id'];}
	
	$location_name = get_location_name ($location_id);
	
	if (isset($_GET['cat'])) {$cat = $_GET['cat'];}
	if (!isset($cat)) {$cat = 0;}
	
	
	//-------[ CATEGORIES ]--------------------------------------//
	//$catresult = get_all_categories ($db);
	
	//-------[ PRODUCTS ]--------------------------------------//
	//$prodresult = get_all_products_orderby_category_id ($db);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Филиал: <? echo ($location_id.'. '.$location_name); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="../../layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="../../layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">

<!--[if lt IE 9]>
<link href="../../layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="../../layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="../../layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
</head>
<body class="">

<? include("../blocks/header.php"); ?>

<!-- ################################################################################################ -->


<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
    
    <!-- ################################################################################################ -->
    <div id="content" class="full-width">
      <section class="">
      	<div> <a id="toggle-right" class="hidden font-large" href="#"><span class="icon-reorder"></span></a></div>
        <br>
        <h1 class="title">
            <span class="icon-building"></span> Филиал: <strong><? echo $location_name; ?></strong>
		</h1>
        
      </section>
      
          
        <!-- ################################################################################################ -->
        
<!--        <h2>Категории</h2>
-->        <div class="clear push50">
          <!-- ################################################################################################ -->
          <div class="tab-wrapper clear">
            <ul class="tab-nav clear">
    <?
        $catresult = get_all_categories ($db);
        $categories = mysqli_fetch_array($catresult);
        do{
            echo ("<li><a href='#tab-".$categories['id']."'>".$categories['name']."</a></li>");
        }while($categories = mysqli_fetch_array($catresult));
    ?>  
            </ul>
            <div class="tab-container">
              <!-- Tab Content -->
    <?
        $catresult = get_all_categories ($db);
        $categories = mysqli_fetch_array($catresult);
        do{
    ?>
    
              <? echo ("<div id='tab-".$categories['id']."' class='tab-content clear';>");?>
                <h1 class="title"><strong><? echo ($categories['name']);?></strong></h1>
                <table class="list-table">
                  <thead>
                    <tr>
                      <th>Продукт</th>
                      <th>Цена<br>(a)</th>
                      <th>К-во<br>Шт. / кг.<br>(x)</th>
                      <th>Получено на<br>&sum;<br>(a*x)</th>
                      <th>Возвраты<br>(z)</th>
                      <th>Возвраты на<br>&sum;<br>(a*z)</th>
                      <th>Осталось<br>(y)</th>
                      <th>Продано<br>[(x-z-y)*a]</th>
                    </tr>
                  </thead>
                  <tbody>
    <?
		
        $prodresult = get_all_products_from_category ($categories['id']);
        $color = "light";
		
		// if there was data
		
		if ($prodresult) {
			$products = mysqli_fetch_array($prodresult);
			$thisLocation = $location_id;
			do{
					
					$thisLocProdData = get_location_product_details ($location_id, $products['id']);
					$amount = get_location_product_amount ($products['id'], $location_id);
					if (!$amount) {
						$amount = 0;
					}
					$price 	= $thisLocProdData["price"];
					$product_id = $products['id'];
					
					// reset
					
					$returnAmount = get_location_product_return_amount ($product_id, $thisLocation);
					$returnPrice = $returnAmount*$price;
					if (!$returnAmount) {$returnAmount = "-"; $returnedPrice = "-";}

					//echo show_error("$product_id, $thisLocation, $returnAmount");
					echo"<tr class='$color'>
						  <td>".$products['name']."</td> <!-- name -->
						  <td>&#8362; ".$price."</td> <!-- price (a) -->";
						  
				    echo" <td class='center'>".$amount."</td> <!-- amount (x) -->
						  <td class='left'>&#8362; ".$received."</td> <!-- received (a*x) -->
						  <td class='center'>".$returnAmount."</td> <!-- returns (z) -->
						  <td class='left'>&#8362; ".$returnPrice."</td> <!-- returned price (a*z) -->
						  <td class='center'>-</td> <!-- last count (y) -->
						  <td class='center'>-</td> <!-- sold total [(x-z-y)*a] -->
						</tr>";
					if($color == "light"){
						$color = "dark";
					}
					else {
						$color = "light";
					}
			}while ($products = mysqli_fetch_array($prodresult));
			
		}
		else {
			
			echo ("<div class='alert-msg warning'>Категория пока что пуста<a class='close' href='#'>X</a></div>");
		}
		?>
					  </tbody>
					</table>
				  </div>
		<?
	 }while($categories = mysqli_fetch_array($catresult));
    ?>
              <!-- / Tab Content -->
            </div>
          </div>
          <!-- ################################################################################################ -->
        </div>

  </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<!-- Footer -->


<? include("../blocks/footer.php"); ?>
<!-- Scripts -->
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>window.jQuery || document.write('<script src="../layout/scripts/jquery-latest.min.js"><\/script>\
<script src="../layout/scripts/jquery-ui.min.js"><\/script>')</script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); });</script>
<script src="../../layout/scripts/jquery-mobilemenu.min.js"></script>
<script src="../../layout/scripts/custom.js"></script>
</body>
</html>